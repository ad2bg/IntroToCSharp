﻿using System;
using System.Collections.Generic;

namespace ConvertNumbersToAnyBase
{
    public class NumberCharacter
    {
        public long DecNumber { get; set; }
        public char Character { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            BaseConverter cnv = new BaseConverter();
            Console.WriteLine(cnv.
                CreateSelectedBaseNumberFromDecimal(10.123456789, 2));
        }
    }

    class BaseConverter
    {
        List<NumberCharacter> CharacterList = populateCharacterList(10);

        static List<NumberCharacter>
            populateCharacterList(int baseNumber)
        {
            // this characterList is a local list and 
            // is returned at the end of the method
            List<NumberCharacter> CharacterList2 = new List<NumberCharacter>();

            //This allows for the program to select from this array ... 
            // up to 26 characters beyond base-10 or... base-36
            char[] arrayChars = {
              'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
              'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

            char[] tempArray = arrayChars;
            int tempNumber = baseNumber;

            //this int will control which character is selected 
            // from the arraryChars Array
            int iterations = 0;
            int value = 0;
            do
            {
                if (value > 9)
                {
                    NumberCharacter nctemp = new NumberCharacter();
                    nctemp.DecNumber = value;
                    nctemp.Character = tempArray[iterations];
                    iterations++;
                    CharacterList2.Add(nctemp);
                    value++;
                    tempNumber--;
                }
                else
                {
                    NumberCharacter nctemp = new NumberCharacter();
                    nctemp.DecNumber = value;
                    nctemp.Character = (char)value;
                    CharacterList2.Add(nctemp);
                    value++;
                    tempNumber--;
                }
            }
            while (tempNumber != 0);
            return CharacterList2;
        }

        string getAssociatedDecimalNumberForCharacter(string passedString)
        {
            foreach (NumberCharacter x in CharacterList)
            {
                if (x.Character.ToString() == passedString)
                { return x.DecNumber.ToString(); }
            }
            return "^";
        }
        string getAssociatedCharacterForDecimalNumber(long tempVal2)
        {
            foreach (NumberCharacter x in CharacterList)
            {
                if (x.DecNumber == tempVal2)
                { return x.Character.ToString(); }
            }
            return "^";
        }


        public string getDecimalNumberForPassedValue(
            string passedNumber, int fromBase)
        {
            List<double> doubleList = new List<double>();

            List<string> characterList = new List<string>();
            List<string> resultsList = new List<string>();
            //intList.Add(1);
            double tempVal = 1;
            //We will add the Decimal Values of Each Place Value to a List
            for (int i = 0; i < passedNumber.Length; i++)
            {
                doubleList.Add(tempVal);
                tempVal = tempVal * fromBase;
                string subString =
                    passedNumber[passedNumber.Length - (i + 1)].ToString();
                //substring is an iteration of each character that is passed 
                // in... we can check to make sure the character is
                // not greater than the value of the fromBase...
                characterList.Add(subString);
            }

            double tempNumber2 = 0;
            for (int j = doubleList.Count - 1; j >= 0; j--)
            {
                double Num;
                bool isNum = double.TryParse(characterList[j], out Num);
                if (isNum)
                {
                    if (double.Parse(characterList[j]) >= fromBase)
                    {
                        ErrorMessage();
                        return "null";
                    }
                    else
                    {
                        double tempVal3 =
                            doubleList[j] * double.Parse(characterList[j]);
                        tempNumber2 = tempNumber2 + tempVal3;
                    }

                }
                else
                {
                    try
                    {
                        string tempString =
                            getAssociatedDecimalNumberForCharacter(
                                characterList[j]);
                        if (double.Parse(tempString) >= fromBase)
                        {
                            ErrorMessage();
                            return "null";
                        }
                        else
                        {
                            //string tempString = 
                            // getAssociatedDecimalNumberForCharacter(
                            // characterList[j]);
                            double tempVal3 =
                                doubleList[j] * double.Parse(tempString);
                            tempNumber2 = tempNumber2 + tempVal3;
                        }
                    }
                    catch (Exception e)
                    {
                        ErrorMessage(e);
                        return "null";
                    }
                }
            }
            string resultsString = tempNumber2.ToString();
            return resultsString;
        }

        static void ErrorMessage(Exception e = null)
        {
            Console.WriteLine(
                "Be Sure the Characters you are using " +
                "Do not go Beyond the bounds of the Selected " +
                "Numbering System... For Example, Do not use the " +
                "letter A in a Decimal Number..." +
                e == null ? "" : e.ToString());
        }

        public string CreateSelectedBaseNumberFromDecimal(
            double DecNumber, int baseNumber)
        {
            //We will add the Decimal Values of Each Place Value's 
            // Exponential Value to a List
            //For instance, for decimal we would add 1, 10, 100, 1000, etc... 
            // These numbers represent the associated exponential value of 
            // the base
            //10^0 = 1; 10^1 = 10; 10^2 = 100... etc... 
            // because each value added to the list also has 
            // an index location... index location 0 for the value 1;
            // index location 1 for the value 10; 
            // index value 2 for the value 100... 
            // these index values also correspond to the associated exponential
            // power for that particular place value
            List<double> doubleList = new List<double>();

            List<string> resultsList = new List<string>();

            double tempVal = 1;
            double tempNumber = DecNumber;
            do
            {
                doubleList.Add(tempVal);
                tempVal = tempVal * baseNumber;
                if (tempVal > tempNumber)
                {
                    tempNumber = 0;
                }
            }
            while (Math.Abs(tempNumber) > double.Epsilon);

            double tempNumber2 = DecNumber;
            for (int i = doubleList.Count - 1; i >= 0; i--)
            {
                double tempVal2 = tempNumber2 / doubleList[i];
                double remainder = tempNumber2 % doubleList[i];
                if (tempVal2 > 0)
                {
                    string tempString5 = tempVal2.ToString()[0].ToString();
                    if (tempVal2 > 10)
                    {
                        tempString5 =
                            getAssociatedCharacterForDecimalNumber(
                                Int64.Parse(
                                    tempVal2.ToString().Substring(0, 2)));
                        double subtractor =
                            double.Parse(
                                getAssociatedDecimalNumberForCharacter(
                                    tempString5)) * doubleList[i];

                        resultsList.Add(tempString5);
                        tempNumber2 = tempNumber2 - subtractor;
                    }
                    else
                    {
                        double subtractor =
                            double.Parse(tempString5) * doubleList[i];
                        resultsList.Add(tempVal2.ToString()[0].ToString());
                        tempNumber2 = tempNumber2 - subtractor;
                    }
                }
                else { resultsList.Add("0"); }
            }
            //return tempNumber2.ToString();
            string resultsString = "";
            foreach (string x in resultsList)
            {
                resultsString = resultsString + x;
            }
            return resultsString;
        }
    }
}
